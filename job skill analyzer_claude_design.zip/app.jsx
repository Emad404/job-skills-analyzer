/* global React, ReactDOM */
const { useState, useEffect, useRef, useCallback } = React;

/* ---------- Inline icon set (simple lucide-style strokes) ---------- */
const Icon = ({ d, paths, size = 20, fill = "none", ...rest }) =>
<svg width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke="currentColor"
strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" {...rest}>
    {d && <path d={d} />}
    {paths}
  </svg>;


const IconSearch = (p) => <Icon {...p} paths={<><circle cx="11" cy="11" r="7" /><path d="m21 21-4.3-4.3" /></>} />;
const IconArrow = (p) => <Icon {...p} paths={<><path d="M5 12h14" /><path d="m13 6 6 6-6 6" /></>} />;
const IconSun = (p) => <Icon {...p} paths={<><circle cx="12" cy="12" r="4" /><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" /></>} />;
const IconMoon = (p) => <Icon {...p} paths={<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z" />} />;
const IconBriefcase = (p) => <Icon {...p} paths={<><rect x="3" y="7" width="18" height="13" rx="2" /><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M3 12h18" /></>} />;
const IconWrench = (p) => <Icon {...p} paths={<path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 0 0 5.4-5.4l-2.6 2.6-2.4-.6-.6-2.4 2.6-2.6Z" />} />;
const IconAward = (p) => <Icon {...p} paths={<><circle cx="12" cy="8" r="5" /><path d="M8.2 12.3 7 22l5-3 5 3-1.2-9.7" /></>} />;
const IconCopy = (p) => <Icon {...p} paths={<><rect x="9" y="9" width="11" height="11" rx="2" /><path d="M5 15V5a2 2 0 0 1 2-2h10" /></>} />;
const IconCheck = (p) => <Icon {...p} paths={<path d="M20 6 9 17l-5-5" />} />;
const IconExternal = (p) => <Icon {...p} paths={<><path d="M15 3h6v6" /><path d="M10 14 21 3" /><path d="M19 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h6" /></>} />;
const IconSparkle = (p) => <Icon {...p} paths={<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3Z" />} />;

/* ---------- Brand logomark: a magnifying glass over ascending skill bars ---------- */
const LogoMark = () =>
<span className="brand-logo" aria-hidden="true">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="10" cy="10" r="7.2" strokeWidth="1.9" />
      <path d="m20.5 20.5-4.7-4.7" strokeWidth="2.2" />
      <path d="M7.4 12.6v-1.8" strokeWidth="1.7" />
      <path d="M10 12.6V9" strokeWidth="1.7" />
      <path d="M12.6 12.6V6.6" strokeWidth="1.7" />
    </svg>
  </span>;


/* ---------- Theme ---------- */
function useTheme() {
  const getInitial = () => {
    const saved = localStorage.getItem("jsa-theme");
    if (saved === "light" || saved === "dark") return saved;
    return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  };
  const [theme, setTheme] = useState(getInitial);
  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("jsa-theme", theme);
  }, [theme]);
  return [theme, () => setTheme((t) => t === "dark" ? "light" : "dark")];
}

/* ---------- Copy-to-clipboard hook ---------- */
function useCopy() {
  const [copied, setCopied] = useState(false);
  const copy = useCallback((text) => {
    navigator.clipboard?.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1600);
    }).catch(() => {});
  }, []);
  return [copied, copy];
}

/* ---------- Header ---------- */
function Header({ theme, toggleTheme }) {
  return (
    <header className="site-header">
      <div className="shell header-inner">
        <a className="brand" href="#" onClick={(e) => e.preventDefault()}>
          <LogoMark />
          <span className="brand-name">Job Skill Analyzer</span>
        </a>
        <button className="theme-toggle" onClick={toggleTheme}
        aria-label="Toggle colour theme">
          {theme === "dark" ? "Light" : "Dark"}
          <span className="knob">{theme === "dark" ? <IconSun size={15} /> : <IconMoon size={15} />}</span>
        </button>
      </div>
    </header>);

}

/* ---------- Hero + search ---------- */
function Hero({ query, setQuery, onAnalyze, loading }) {
  const popular = window.JSA_DATA.popular;
  return (
    <section className="hero shell">
      <h1 style={{ fontFamily: "Newsreader" }}>
        What does <span className="hl-solid">any</span> <em>job role</em><br />
        actually require?
      </h1>
      <p className="sub">
        Enter a job title and get a structured breakdown of the exact skills, tools,
        and certifications hiring managers look for today — plus a roadmap to get there.
      </p>

      <div className="search-wrap">
        <form className="search-bar" onSubmit={(e) => {e.preventDefault();onAnalyze(query);}}>
          <IconSearch className="search-icon" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="e.g. Data Analyst, UX Designer, DevOps Engineer…"
            aria-label="Job title" />
          
          <button className="btn-analyze" type="submit" disabled={loading}>
            {loading ? <span className="spinner" /> : <>Analyze <IconArrow /></>}
          </button>
        </form>

        <div className="popular">
          <span className="label">Popular</span>
          {popular.map((r) =>
          <button key={r} className="chip-role" onClick={() => onAnalyze(r)}>{r}</button>
          )}
        </div>
      </div>
    </section>);

}

/* ---------- Requirement card ---------- */
function ReqCard({ icon, title, items }) {
  const [copied, copy] = useCopy();
  return (
    <div className="req-card">
      <div className="card-head">
        <div className="card-title">
          <span className="card-icon">{icon}</span>
          <h3>{title}</h3>
        </div>
        <button className={"copy-btn" + (copied ? " copied" : "")}
        onClick={() => copy(items.join("\n"))}>
          {copied ? <><IconCheck /> Copied</> : <IconCopy />}
        </button>
      </div>
      <div className="tag-list">
        {items.map((t) => <span className="tag" key={t}>{t}</span>)}
      </div>
    </div>);

}

/* ---------- Results ---------- */
function Results({ data }) {
  const [roadCopied, copyRoad] = useCopy();
  return (
    <section className="results shell fade-up">
      <div className="results-head">
        <div className="role-line">
          <span className="kicker">Breakdown</span>
          <h2>{data.title}</h2>
        </div>
      </div>

      <div className="section-label">Requirements</div>
      <div className="cards">
        <ReqCard icon={<IconBriefcase />} title="Skills" items={data.skills} />
        <ReqCard icon={<IconWrench />} title="Tools" items={data.tools} />
        <ReqCard icon={<IconAward />} title="Certifications" items={data.certifications} />
      </div>

      <div className="section-label">
        Career roadmap
        <button className={"copy-btn" + (roadCopied ? " copied" : "")}
        onClick={() => copyRoad(data.roadmap.map((s, i) => `${i + 1}. ${s}`).join("\n"))}>
          {roadCopied ? <><IconCheck /> Copied</> : <><IconCopy /> Copy</>}
        </button>
      </div>
      <div className="roadmap">
        {data.roadmap.map((step, i) =>
        <div className="roadmap-step" key={i}>
            <span className="step-num">{i + 1}</span>
            <div className="step-body"><p>{step}</p></div>
          </div>
        )}
      </div>

      <div className="section-label">Recommended courses</div>
      <div className="courses">
        {data.courses.map((c, i) =>
        <div className="course-row" key={i}>
            <span className="course-idx">{String(i + 1).padStart(2, "0")}</span>
            <div className="course-main">
              <div className="course-name">{c.name}</div>
              <div className="course-prov">{c.provider}</div>
            </div>
            <a className="course-link" href="#" onClick={(e) => e.preventDefault()}>
              {c.action} <IconExternal />
            </a>
          </div>
        )}
      </div>
    </section>);

}

/* ---------- Loading skeleton ---------- */
function ResultsSkeleton() {
  return (
    <section className="results shell">
      <div className="results-head">
        <div className="role-line" style={{ gap: 10 }}>
          <div className="skeleton" style={{ width: 90, height: 12 }} />
          <div className="skeleton" style={{ width: 240, height: 36 }} />
        </div>
      </div>
      <div className="section-label">Requirements</div>
      <div className="cards">
        {[0, 1, 2].map((c) =>
        <div className="req-card" key={c}>
            <div className="skeleton" style={{ width: 130, height: 18, marginBottom: 20 }} />
            <div className="tag-list">
              {[60, 90, 75, 110, 70, 85].map((w, i) =>
            <div className="skeleton" key={i} style={{ width: w, height: 34, borderRadius: 9 }} />
            )}
            </div>
          </div>
        )}
      </div>
    </section>);

}

/* ---------- App ---------- */
function App() {
  const [theme, toggleTheme] = useTheme();
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState(null);
  const timer = useRef(null);

  const analyze = (q) => {
    const term = (q || "").trim();
    if (!term) return;
    setQuery(term);
    setLoading(true);
    setData(null);
    clearTimeout(timer.current);
    timer.current = setTimeout(() => {
      setData(window.JSA_DATA.lookup(term));
      setLoading(false);
    }, 750);
  };

  return (
    <>
      <Header theme={theme} toggleTheme={toggleTheme} />
      <main>
        <Hero query={query} setQuery={setQuery} onAnalyze={analyze} loading={loading} />
        {loading && <ResultsSkeleton />}
        {!loading && data && <Results data={data} />}
      </main>
      <footer className="site-footer">
        <div className="shell footer-inner">
          <span>Job Skill Analyzer <span className="dot" /> Built for clarity, not buzzwords</span>
          <span>Demo data · {new Date().getFullYear()}</span>
        </div>
      </footer>
    </>);

}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);