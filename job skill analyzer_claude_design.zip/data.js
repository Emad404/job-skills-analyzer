/* ============================================================
   Preset role data for the Job Skill Analyzer demo.
   Attached to window.JSA_DATA. Keys are lowercased role titles.
   ============================================================ */
(function () {
  const roles = {
    "data analyst": {
      title: "Data Analyst",
      summary: "Turns raw data into decisions — querying, modelling and visualising for the business.",
      skills: [
        "SQL Querying & Database Management", "Data Cleaning & Preprocessing",
        "Statistical Analysis & Modelling", "Data Visualisation & Storytelling",
        "Business Acumen & Domain Knowledge", "Dashboard Design & Reporting",
        "Predictive Analytics Fundamentals", "Communication & Presentation"
      ],
      tools: [
        "SQL (PostgreSQL, MySQL, SQL Server)", "Python (Pandas, NumPy, Matplotlib)",
        "R (tidyverse, ggplot2)", "Microsoft Excel (Advanced, Power Query)",
        "Tableau", "Microsoft Power BI", "Jupyter / RStudio", "Google Analytics"
      ],
      certifications: [
        "Google Data Analytics Professional Certificate", "IBM Data Analyst Professional Certificate",
        "Microsoft Certified: Power BI Data Analyst Associate", "Tableau Desktop Specialist",
        "SAS Certified Specialist: Base Programming", "Certified Analytics Professional (CAP)",
        "CompTIA Data+"
      ],
      roadmap: [
        "Master SQL for data extraction and manipulation across relational database systems.",
        "Build programming fluency in Python or R for cleaning, analysis and automation.",
        "Develop visualisation skills in Tableau or Power BI to ship clear, impactful dashboards.",
        "Learn core statistics — apply them to interpret data, find trends and make recommendations.",
        "Assemble a portfolio of end-to-end projects that prove your analysis workflow.",
        "Acquire domain knowledge for a target industry (finance, healthcare, marketing).",
        "Sharpen storytelling — translate complex findings into clear, actionable advice.",
        "Explore A/B testing, forecasting and foundational ML for predictive work."
      ],
      courses: [
        { name: "Google Data Analytics Professional Certificate", provider: "Coursera · Google", action: "Enroll" },
        { name: "IBM Data Analyst Professional Certificate", provider: "Coursera · IBM", action: "Enroll" },
        { name: "Power BI Data Analyst Associate Learning Path", provider: "Microsoft Learn", action: "View" },
        { name: "SQL for Data Science", provider: "Coursera · IBM", action: "Enroll" },
        { name: "Python for Everybody Specialization", provider: "University of Michigan", action: "Enroll" },
        { name: "Data Visualization with Tableau", provider: "UC Davis", action: "Enroll" },
        { name: "Introduction to Statistics", provider: "Stanford University", action: "Enroll" }
      ]
    },

    "software engineer": {
      title: "Software Engineer",
      summary: "Designs, builds and maintains reliable software systems end to end.",
      skills: [
        "Data Structures & Algorithms", "Object-Oriented & Functional Design",
        "System Design & Architecture", "Testing & Debugging", "API Design (REST / GraphQL)",
        "Version Control & Code Review", "Databases & Data Modelling", "Concurrency & Performance"
      ],
      tools: [
        "Git & GitHub / GitLab", "VS Code / JetBrains IDEs", "Docker & Kubernetes",
        "Python · JavaScript / TypeScript · Go", "PostgreSQL / Redis", "CI/CD (GitHub Actions, Jenkins)",
        "AWS / GCP", "Linux & Bash"
      ],
      certifications: [
        "AWS Certified Developer – Associate", "Oracle Certified Professional: Java SE",
        "Microsoft Certified: Azure Developer Associate", "Certified Kubernetes Application Developer",
        "Google Associate Cloud Engineer", "Meta Back-End Developer Certificate"
      ],
      roadmap: [
        "Build rock-solid fundamentals in data structures, algorithms and complexity.",
        "Become fluent in one language and its ecosystem before broadening out.",
        "Learn version control, code review and collaborative Git workflows.",
        "Practise writing tested, maintainable code with clear interfaces.",
        "Study system design — scalability, caching, queues and trade-offs.",
        "Ship full projects with a database, API and deployed front end.",
        "Get comfortable with Docker, CI/CD and cloud deployment.",
        "Contribute to open source and read large codebases to level up."
      ],
      courses: [
        { name: "CS50: Introduction to Computer Science", provider: "Harvard · edX", action: "Enroll" },
        { name: "Meta Back-End Developer Professional Certificate", provider: "Coursera · Meta", action: "Enroll" },
        { name: "The Odin Project — Full Stack", provider: "The Odin Project", action: "View" },
        { name: "Algorithms Specialization", provider: "Stanford University", action: "Enroll" },
        { name: "Docker & Kubernetes: The Complete Guide", provider: "Udemy", action: "Enroll" },
        { name: "AWS Cloud Practitioner Essentials", provider: "AWS Skill Builder", action: "View" },
        { name: "Designing Data-Intensive Applications (book)", provider: "O'Reilly", action: "Read" }
      ]
    },

    "ux designer": {
      title: "UX Designer",
      summary: "Researches users and crafts intuitive, accessible product experiences.",
      skills: [
        "User Research & Interviewing", "Information Architecture", "Wireframing & Prototyping",
        "Interaction Design", "Usability Testing", "Visual & UI Design",
        "Accessibility (WCAG)", "Design Systems & Documentation"
      ],
      tools: [
        "Figma", "FigJam / Miro", "Adobe XD", "Maze / UserTesting",
        "Notion", "Principle / ProtoPie", "Dovetail", "Zeplin"
      ],
      certifications: [
        "Google UX Design Professional Certificate", "Nielsen Norman Group UX Certification",
        "Interaction Design Foundation Certificate", "Certified Usability Analyst (CUA)",
        "IxDF Accessibility Certificate", "Adobe Certified Professional"
      ],
      roadmap: [
        "Learn the UX process — discovery, definition, ideation, testing, iteration.",
        "Practise user research: interviews, surveys and synthesising insights.",
        "Master information architecture and user-flow mapping.",
        "Build wireframing and prototyping fluency in Figma.",
        "Run usability tests and learn to act on the findings.",
        "Develop visual design and a working knowledge of design systems.",
        "Internalise accessibility standards and inclusive design.",
        "Ship a portfolio of case studies that show your thinking, not just screens."
      ],
      courses: [
        { name: "Google UX Design Professional Certificate", provider: "Coursera · Google", action: "Enroll" },
        { name: "Introduction to User Experience Design", provider: "Georgia Tech · Coursera", action: "Enroll" },
        { name: "Design Thinking Specialization", provider: "UC San Diego", action: "Enroll" },
        { name: "Figma for UX Design", provider: "Interaction Design Foundation", action: "View" },
        { name: "Accessibility: How to Design for All", provider: "IxDF", action: "Enroll" },
        { name: "Usability Testing Course", provider: "Nielsen Norman Group", action: "View" }
      ]
    },

    "product manager": {
      title: "Product Manager",
      summary: "Owns the why and what of a product — strategy, prioritisation and delivery.",
      skills: [
        "Product Strategy & Vision", "Roadmapping & Prioritisation", "User & Market Research",
        "Data-Driven Decision Making", "Stakeholder Management", "Agile & Scrum Delivery",
        "Writing PRDs & User Stories", "Go-to-Market Planning"
      ],
      tools: [
        "Jira / Linear", "Notion / Confluence", "Figma", "Amplitude / Mixpanel",
        "Productboard", "SQL (basics)", "Looker / Tableau", "Slack & Loom"
      ],
      certifications: [
        "Certified Scrum Product Owner (CSPO)", "Pragmatic Institute Certification",
        "Product School: Product Manager Certificate", "Google Project Management Certificate",
        "Reforge Product Strategy", "SAFe Product Owner / Product Manager"
      ],
      roadmap: [
        "Understand the product lifecycle and the PM's role across it.",
        "Learn to talk to users and turn research into clear problems.",
        "Practise prioritisation frameworks (RICE, MoSCoW, opportunity scoring).",
        "Write crisp PRDs, user stories and acceptance criteria.",
        "Get fluent with product analytics and core metrics.",
        "Master agile delivery and working with engineering and design.",
        "Develop go-to-market and stakeholder-communication skills.",
        "Build a portfolio of shipped outcomes, not just features."
      ],
      courses: [
        { name: "Digital Product Management Specialization", provider: "University of Virginia", action: "Enroll" },
        { name: "Become a Product Manager", provider: "Product School", action: "View" },
        { name: "Google Project Management Certificate", provider: "Coursera · Google", action: "Enroll" },
        { name: "Agile Development Specialization", provider: "University of Virginia", action: "Enroll" },
        { name: "Product Analytics Micro-Cert", provider: "Amplitude Academy", action: "View" },
        { name: "Reforge — Product Strategy", provider: "Reforge", action: "View" }
      ]
    },

    "devops engineer": {
      title: "DevOps Engineer",
      summary: "Automates infrastructure, pipelines and reliability across the delivery lifecycle.",
      skills: [
        "Infrastructure as Code", "CI/CD Pipeline Design", "Containerisation & Orchestration",
        "Cloud Architecture", "Monitoring & Observability", "Scripting & Automation",
        "Networking & Security", "Site Reliability Practices"
      ],
      tools: [
        "Docker & Kubernetes", "Terraform / Pulumi", "Ansible", "AWS / Azure / GCP",
        "GitHub Actions / GitLab CI / Jenkins", "Prometheus & Grafana", "Bash & Python", "Helm"
      ],
      certifications: [
        "AWS Certified DevOps Engineer – Professional", "Certified Kubernetes Administrator (CKA)",
        "HashiCorp Certified: Terraform Associate", "Microsoft Certified: DevOps Engineer Expert",
        "Docker Certified Associate", "Google Professional Cloud DevOps Engineer"
      ],
      roadmap: [
        "Get strong with Linux, networking and shell scripting.",
        "Learn a cloud provider's core compute, storage and IAM services.",
        "Master containers with Docker, then orchestration with Kubernetes.",
        "Adopt infrastructure as code using Terraform.",
        "Build CI/CD pipelines that test and deploy automatically.",
        "Set up monitoring, logging and alerting for observability.",
        "Practise security, secrets management and least-privilege access.",
        "Study SRE principles — SLOs, error budgets and incident response."
      ],
      courses: [
        { name: "DevOps on AWS Specialization", provider: "AWS · Coursera", action: "Enroll" },
        { name: "Docker & Kubernetes: The Complete Guide", provider: "Udemy", action: "Enroll" },
        { name: "HashiCorp Terraform Associate Prep", provider: "HashiCorp Learn", action: "View" },
        { name: "Certified Kubernetes Administrator Prep", provider: "Linux Foundation", action: "Enroll" },
        { name: "Site Reliability Engineering (book)", provider: "Google · O'Reilly", action: "Read" },
        { name: "CI/CD with GitHub Actions", provider: "GitHub Skills", action: "View" }
      ]
    },

    "cybersecurity analyst": {
      title: "Cybersecurity Analyst",
      summary: "Defends systems and data — monitoring threats, hardening and responding to incidents.",
      skills: [
        "Network Security & Protocols", "Threat Detection & SIEM", "Vulnerability Assessment",
        "Incident Response", "Security Frameworks (NIST, ISO 27001)", "Identity & Access Management",
        "Scripting for Security", "Risk Analysis & Compliance"
      ],
      tools: [
        "Wireshark", "Splunk / Elastic SIEM", "Nmap", "Metasploit",
        "Burp Suite", "Nessus / Qualys", "Linux & Bash", "Python"
      ],
      certifications: [
        "CompTIA Security+", "CompTIA CySA+", "Certified Ethical Hacker (CEH)",
        "GIAC Security Essentials (GSEC)", "Certified Information Systems Security Professional (CISSP)",
        "Microsoft Certified: Security Operations Analyst"
      ],
      roadmap: [
        "Build foundations in networking, operating systems and the CIA triad.",
        "Learn common threats, attack vectors and the MITRE ATT&CK framework.",
        "Get hands-on with a SIEM for monitoring and log analysis.",
        "Practise vulnerability scanning and basic penetration testing.",
        "Learn incident response and digital forensics fundamentals.",
        "Study security frameworks, governance and compliance.",
        "Develop scripting skills to automate detection and triage.",
        "Earn an industry certification and build a home lab portfolio."
      ],
      courses: [
        { name: "Google Cybersecurity Professional Certificate", provider: "Coursera · Google", action: "Enroll" },
        { name: "CompTIA Security+ (SY0-701) Prep", provider: "CompTIA", action: "View" },
        { name: "IBM Cybersecurity Analyst Certificate", provider: "Coursera · IBM", action: "Enroll" },
        { name: "Introduction to Cyber Security Specialization", provider: "NYU", action: "Enroll" },
        { name: "TryHackMe — SOC Analyst Path", provider: "TryHackMe", action: "View" },
        { name: "Practical Ethical Hacking", provider: "TCM Security", action: "View" }
      ]
    }
  };

  // Generic fallback for any role not in the preset list.
  function fallback(query) {
    const title = query.replace(/\b\w/g, c => c.toUpperCase());
    return {
      title,
      summary: "A structured starting point — refine with a role above for a tailored breakdown.",
      generic: true,
      skills: [
        "Core Domain Fundamentals", "Problem Solving & Analysis", "Written & Verbal Communication",
        "Collaboration & Teamwork", "Project & Time Management", "Data Literacy",
        "Continuous Learning", "Stakeholder Awareness"
      ],
      tools: [
        "Industry-Standard Software", "Spreadsheets & Documentation", "Project Management Tools",
        "Communication Platforms", "Analytics & Reporting Tools", "Version / File Management"
      ],
      certifications: [
        "Relevant Professional Certificate", "Recognised Industry Body Credential",
        "Foundational Skills Certification", "Specialised Tool Certification"
      ],
      roadmap: [
        "Map the core responsibilities and day-to-day work of the role.",
        "Build foundational knowledge of the field's key concepts.",
        "Learn the standard tools used by professionals in this area.",
        "Practise with small, realistic projects to build confidence.",
        "Seek mentorship and study how experienced people work.",
        "Assemble a portfolio that demonstrates real capability.",
        "Earn a recognised certification to validate your skills.",
        "Stay current — follow industry trends and keep practising."
      ],
      courses: [
        { name: "Foundational Course for " + title, provider: "Coursera", action: "Browse" },
        { name: "Professional Certificate Programs", provider: "edX", action: "Browse" },
        { name: "Hands-on Specialisations", provider: "Udemy", action: "Browse" },
        { name: "Free Learning Paths", provider: "LinkedIn Learning", action: "Browse" }
      ]
    };
  }

  window.JSA_DATA = {
    roles,
    popular: ["Data Analyst", "Software Engineer", "UX Designer", "Product Manager", "DevOps Engineer", "Cybersecurity Analyst"],
    lookup(query) {
      const key = (query || "").trim().toLowerCase();
      if (!key) return null;
      if (roles[key]) return roles[key];
      // loose contains match
      const hit = Object.keys(roles).find(k => k.includes(key) || key.includes(k));
      return hit ? roles[hit] : fallback(query.trim());
    }
  };
})();
